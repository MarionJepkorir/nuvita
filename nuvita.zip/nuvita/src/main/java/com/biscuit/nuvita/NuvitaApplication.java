package com.biscuit.nuvita;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NuvitaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NuvitaApplication.class, args);
	}

}
